深渊无尽 · 天赋猎手 — Windows 桌面版
====================================

运行：
  双击 AbyssTalentHunter.exe

系统要求：
  Windows 10 / Windows 11（64 位）
  Microsoft Edge WebView2 Runtime（Windows 11 通常已自带；如缺失，首次启动会提示下载）

说明：
  - 绿软，免安装。整个文件夹可以复制、压缩后发给别人。
  - 游戏存档保存在文件夹内的 UserData 目录中，不同电脑之间不互通。
  - 请把整个文件夹放在有写入权限的位置（例如桌面或 D 盘），不要放进 Program Files。
  - 解压后不要单独移动 exe；exe 必须和 app、*.dll 放在同一文件夹。
  - F11 暂未绑定全屏，可直接最大化窗口；Alt+F4 退出。
